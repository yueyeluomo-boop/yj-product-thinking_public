# Yangjun Product Thinking Profile

This profile distills the user's preferred product judgment and communication logic from 24 positive examples and user annotations. It is a working draft, not a universal PM methodology.

## 1. Core Orientation

The user's strongest pattern is: start from the business/user problem, build a compact but credible judgment chain, then choose an output shape based on the audience's job.

The goal is not always "make a decision." Boss-facing or cross-team documents may instead need to:

- Help leaders understand a business mechanism.
- Build trust in a non-obvious judgment.
- Align teams on a shared frame.
- Expose a risk before launch.
- Support a fast decision when the direction is already mostly agreed.

Do not force every document into a decision memo. First classify what the reader should gain: understanding, trust, decision, alignment, escalation, or execution clarity.

## 2. Preferred Thinking Sequence

Use this sequence before rewriting or drafting:

1. Identify the real business question.
   - What is the thing being judged?
   - Why does it matter now?
   - What business/user result does it connect to?
2. Identify the audience job.
   - Boss needs understanding, decision, confidence, or risk awareness?
   - Collaborators need task split, problem frame, or metric definition?
   - Execution team needs checklist, funnel, owner map, or risk list?
3. Choose the document mode.
   - Thought sync.
   - Fast decision support.
   - Stage summary.
   - Business review / OKR.
   - Methodology / operating framework.
   - Experiment recovery.
   - Project kickoff / one-pager.
4. Preserve the strongest reasoning asset.
   - If the source's value is its logic chain, do not compress it into generic "结论-风险-下一步".
   - If the source's value is fast decision support, do not overbuild business theory.
   - If the source's value is project coordination, do not turn it into strategic prose.
5. Output in the minimum structure that makes the judgment credible and usable.

## 3. Boss-Facing Materials

Boss-facing does not equal "决策 memo." The profile distinguishes at least four boss-facing modes.

### Thought Sync

Use when the document is a leader's or PM's key thinking, not a formal decision request.

Preferred pattern:

- Briefly introduce the business context.
- Define the key classification or judgment frame.
- For each direction, explain what it means, when it is good, when it is bad, and what should be built or watched.
- End with a shared language or operating principle.

Do not add artificial decision asks if the original material is meant to synchronize thinking.

### Fast Decision Support

Use when the direction is mostly agreed and the document needs a quick go/no-go, rollout, or resource decision.

Preferred pattern:

- Short background.
- Clear current decision.
- Data table grouped by decision-relevant dimensions.
- Module conclusions only where they affect the decision.
- Risks, monitoring, and action calendar.

Do not add lengthy business logic if the decision audience already understands the context.

### Stage Summary

Use when syncing progress with a business owner.

Preferred pattern:

- Key progress and metric movement.
- The few facts that explain the movement.
- What has actually been done.
- The next focus.

Avoid over-learning exact prose from rough summaries; learn the shape and information density.

### Formal Business Review / OKR

Use when communicating to company management or quarterly review.

Preferred pattern:

- Serious, compact, polished language.
- Lead with core result and whether it met expectation.
- Explain what was done right, what changed structurally, and what next quarter focuses on.
- Separate planning logic from historical work logs.

Avoid decision framing when the document is meant to summarize and align, not ask for approval.

## 4. Business Judgment Logic

The preferred judgment style is practical and mechanism-oriented:

- State whether a thing is worth doing by connecting it to business result and user behavior.
- Break the problem by mechanism, not by org chart.
- Define how the business should be measured before proposing what to do.
- Use both qualitative user demand and quantitative indicators where available.
- Keep risk visible, especially before high-cost launches.

Common judgment frames:

- Should we do this category or direction?
- What business mechanism makes it work?
- What metric proves it is working?
- What risks can make delivery fail to translate into result?
- Which segment/source/module is the real bottleneck?

When describing a complex business, prefer:

1. Business goal.
2. Current problem or opportunity.
3. Mechanism or operating framework.
4. Measurement method.
5. Levers / strategy.
6. Risks and next validation.

## 5. Experiment And Data Reasoning

The preferred experiment-analysis style values validity before conclusion.

Core sequence:

1. Clarify the experiment purpose and original demand hypothesis.
2. Check whether the experiment setup and metric口径 support that purpose.
3. Read core metrics and process metrics separately.
4. Map metric movement back to user behavior or chain changes.
5. Decide: can push, continue observe, iterate, stop, or treat conclusion as invalid.
6. Explain what to do next.

Important rules:

- A metric being green is not enough; explain whether it represents the intended user behavior.
- Do not use stale or overly specific historical indicators as rigid rules.
- Do not overfit old cases. Use them to learn evaluation principles.
- For abnormal experiments, explicitly separate accident, invalid conclusion, recovery action, and future prevention.
- When a result is mixed, state which metric is core, which is process, and which is guardrail.

Good experiment writing should make the收益链路 visible:

```text
需求假设 -> 实验变量 -> 核心指标 -> 过程指标 -> 用户行为解释 -> 决策 -> 下一步
```

## 6. Project And Scheme Alignment

For project kickoff or scheme discussion, the preferred style is concise but operational.

Project kickoff should answer:

- What is the project?
- Why do it?
- What stage goal are we validating?
- What is the rough management model?
- Which modules/owners/dependencies matter?
- What is not representative or should not be over-learned?

For mature one-pagers, include:

- Project background.
- Core plan.
- Module split from both internal and collaborator perspectives.
- Technical/test plan when needed.
- Timeline.
- Communication mechanism.
- Owner map.

For scheme discussion:

- Start with the problem the scheme solves.
- Present only viable options.
- Compare by business impact, user impact, cost, risk, reversibility, and speed.
- Keep appendices and historical memos out of the main path unless they affect the decision.

### Management-Alignment Discussion Docs

Use this mode when a project needs several rounds of alignment with management or upstream/downstream teams: what to do, where the opportunity is, which product/operation changes are in scope, and how to validate.

Preferred pattern:

- Start with the last round's conclusion and this round's job: what needs to be aligned now, not the whole background again.
- State the business/user question before the product solution. For opportunity analysis, explain why the current approach may be supply-driven, vague, or unable to expose growth levers.
- Use data to narrow the opportunity, not to display all analysis. Good summaries show the口径, the opportunity movement, the excluded categories, and the final category judgment.
- Write product strategy changes as "from X -> Y" only when the shift is real; immediately explain why, what stays unchanged, and what is not solved this round.
- Keep scope boundaries explicit: "not this stage", "does not support push-full", "directly replacing this would blur the expression", or "this conclusion supports A but not B".
- Use tables when they express a judgment system, such as user decision questions across categories. Add a paragraph before or after the table to explain the takeaway.

For detailed patterns, read `project-discussion-patterns.md`.

## 7. Preferred Writing Style

The desired style is:

- Concise but not hollow.
- Structured but not template-heavy.
- Business-first, with enough data to be credible.
- Compression-first for submitted text: unless the user explicitly asks to expand, the rewrite should reduce words, or at most keep the same length. Improve information density by deleting unsupported evaluations and vague positive summaries.
- Willing to say "this is a proxy" or "this is not a direct measurement."
- Clear about what should and should not be learned from a case.
- Uses compact classification to make complexity easier to discuss.
- Balances paragraphs and tables: paragraphs should carry the core judgment, reasoning, and transitions; tables should carry comparison, evidence,口径, tradeoffs, or division of responsibilities.

Structural preference:

- Keep the opening overview short and high-signal.
- Give key argument sections enough paragraph development to make the judgment credible.
- Use tables selectively for information density, not as the default skeleton for every requirement.
- If a section contains an important "why", "so what", or decision boundary, do not let the table replace the paragraph explanation.
- Treat user instructions about audience, alignment, or tone as implicit document-shaping constraints. Do not echo them as literal headings unless that section is genuinely useful. For example, "适合与上级对齐" should affect what is前置、how risk and evidence are framed, and how conclusions are worded; it should not automatically produce a heading like "需要和上级对齐什么".

Good phrasing habits:

- "这个问题本质上是..."
- "当前最关键的判断是..."
- "这不是严格的真实值，而是用于排序和治理的代理指标。"
- "这里需要区分两类场景..."
- "这个结论可以支持...，但不能支持..."
- "后续重点不是继续证明这个方向，而是..."

Avoid:

- Generic management-consulting rewrites.
- Adding non-factual filler such as "整体表现持续向好", "取得了阶段性成效", "为后续发展奠定基础", or similar phrases unless the source gives concrete metric, milestone, or business evidence. These phrases usually have no information-transfer value.
- Expanding a submitted text just to make it sound more complete. If the user did not ask for expansion, remove weak modifiers, duplicated context, and unsupported implication.
- Forcing every document into "结论 / 风险 / 下一步".
- Turning every requirement into a table. Too many tables make the document feel uniform, compressed, and generic; too few tables can make dense evidence hard to scan.
- Literalizing the user's meta-instructions into document titles or section headings. Audience requirements should shape the whole document, not appear as awkward labels copied from the prompt.
- Over-polishing rough working documents until they lose operational meaning.
- Replacing a valuable reasoning chain with a superficial executive summary.
- Treating all boss-facing docs as decision requests.
- Learning sections the user explicitly marked as stale, verbose, too case-specific, or not representative.

## 8. Rewrite Procedure

Before rewriting any document in this style, perform a short diagnosis:

```text
文档类型：
读者应该获得什么：
原文最有价值的资产：
应该前置的内容：
应该后置或压缩的内容：
是否允许扩写：
不能学/不能套用的内容：
建议改写策略：
```

Only after this diagnosis should the rewrite begin.

For short submitted passages, treat "是否允许扩写" as "no" by default. Expand only when the user explicitly asks for richer reasoning, missing context, or a full document section.

For complex source material, offer 2-3 possible rewrite structures before producing a final full rewrite when the user's intent is ambiguous.

## 9. Anti-Patterns From The Failed Geo Rewrite

The previous "机位地理位置质量评估与治理建议（老板决策版）" rewrite was not successful because it over-converted a reasoning-heavy evaluation document into a generic decision memo.

Likely failure modes to avoid:

- It assumed "面向老板" means "需要老板拍板".
- It front-loaded decision tables before preserving why the proxy metric was credible.
- It compressed the most valuable asset: the construction of "一致率 as proxy".
- It made the output feel like a standard management summary rather than the user's own reasoning path.
- It overused template sections such as "需要老板判断的事" without proving whether that was the right document mode.
- It overused tables as the primary expression form, which hid the reasoning that should have been developed in paragraphs.
- It turned "面向老板/对齐" into visible template labels instead of letting that requirement shape the document's overall framing and expression.

Better approach for that class of document:

- Classify it as "business understanding + trust-building for a technical/data judgment", not pure decision memo.
- Start with why the question matters to business.
- Keep the proxy-metric reasoning as the central spine.
- Then translate the implication into governance priority and decision boundary.
- State what the conclusion can support and what it cannot support.
- Let the overview stay compact, then develop the key argument sections in paragraphs; use tables only for evidence,口径, option comparison, or responsibility alignment.

## 10. Mixed Audience: Upstream, Downstream, And Management

When the user asks for "上下游及管理层对齐讨论", the document should not be only an executive summary.

Use this mode:

- Management needs to understand the business value, risk, and priority.
- Upstream teams need to understand why their capability/data/process matters and what input is needed.
- Downstream teams need to understand how the conclusion affects product, audit, recommendation, operations, or monitoring.
- The document should create a shared discussion frame, not hide the reasoning.

Preferred structure:

1. Why this topic matters to the business/user path.
2. What question we are trying to align.
3. What evidence and reasoning currently supports the judgment.
4. What conclusion is usable now, and what boundary it has.
5. What each group needs to discuss or confirm.
6. What next action or pilot can reduce uncertainty.
