# Project Discussion Patterns

Use these patterns for product documents that need to align management, upstream/downstream partners, or project teams on a non-obvious opportunity or scheme. This reference was distilled from anonymized annotated examples; learn the writing logic, not any specific source domain.

## 1. Opening: Last Round To This Round

For multi-round discussion docs, do not restart from a generic background. Open by anchoring:

- Last round's conclusion and todo.
- The principle already agreed.
- This round's deliverable: what must be aligned now.

Good shape:

```text
上次结论：
- ...
- ...

本次要交付：
1. 容器/产品具体怎么改，就着 case 对齐。
2. 运营/供给具体怎么改，就着 case 对齐。
3. 哪些问题不是本阶段解决。
```

When reviewing specific changes, write each item as:

```text
拟改动（依据：为什么提出）——判断：做 / 不做 / 暂不做 / 拆成两个字段 / 保持旧容器但扩供给
```

This keeps the document discussion-oriented: readers can see the proposal, basis, and decision boundary in one pass.

## 2. Background: From Current Path To Real Question

When the document is about an opportunity, first challenge the current path before proposing the new answer.

Preferred pattern:

- Current approach: what it optimizes for.
- Problem: why that approach may be too supply-driven, vague, or unable to reveal growth levers.
- Real question: what user/business information must be identified.
- Criteria: what kinds of cases count as opportunities.

Example logic:

```text
当前思路更多从供给生产出发，而不是从用户信息需求出发。
问题是：做完后可能仍然模糊，识别不了增长机会和后续手段。
因此要回答：哪些信息类型具备结构化沉淀价值？
筛选特征：非门店、POI 难表达、信息散落、用户需要大量筛选才能获取。
```

## 3. Data: Compress Large Analysis Into Judgment

Do not reproduce all tables in the main path. Use data to narrow opportunities.

A useful data paragraph contains:

- Data source and口径.
- The screening method.
- The main movement or scale.
- What is excluded and why.
- The final opportunity judgment.

Good shapes:

```text
看增幅倒排：主要机会点是 A / B，从 x% -> y%。
结论：A 增长明显，但其中 A1 时效要求高、A2 风险大，因此核心关注 A3。
```

```text
看大盘占比且不跌：主要基本盘是 A / B。
结论：A 有规模，B 有稳定需求；C 虽然占比高，但门店依赖强，不作为本轮重点。
```

For big datasets, group by decision meaning, not by raw labels:

- 增长机会: what is rising.
- 基本盘: what has scale and is stable.
- 剔除项: what looks attractive but violates the boundary.
- 最终判断: which lines become product directions.

## 4. Experiment: Decision First, Metrics Second

For experiment conclusions, lead with the decision and next action before metric details.

Preferred order:

1. Decision: push, continue, stop, or invalid.
2. Next todo.
3. What evidence would be required to push.
4. Metrics grouped by platform, surface, or chain.

For mixed results, name the negative core metric directly. Do not let positive process metrics hide a failed business chain.

## 5. Tables: Use Them To Express A Viewpoint

Use tables when rows and columns encode the judgment system.

Good table rows:

- User decision questions: `值不值得去`, `怎么定`, `怎么去`, `到了怎么玩`, `怎么不踩坑`, `要准备什么`, `适不适合我`, `什么时候去最好`, `怎么拍`, `附近还有什么`.
- Strategy dimensions: old constraint, new extension, why, unchanged part, risk.
- Category comparison: category A / B / C and the information each needs.

Do not make a table just because there is a lot of text. A good table needs a sentence before or after it:

```text
一句话：应该结构化、但表达还不统一/没有标准解决方案的是 A、B、C。
```

## 6. Product Strategy Changes

Write real changes as `from X -> Y`, then explain the operational meaning.

Good pattern:

```text
头图：单点位出片 -> 地点体验
含义：原类型仍保持旧限制；扩展类型放宽为 POI 临近、玩法一致、共同表达这个地点是否值得去。
边界：不直接改旧容器名字，避免用户视角差异不大但成本增加。
```

For field or container changes, distinguish:

- What stays unchanged for legacy scenarios.
- What is added for new scenarios.
- Why direct replacement would blur meaning.
- Which issues are explicitly not solved this round.

## 7. Stage Plan

For project plans, avoid a flat task list. Use stages that each answer a business question.

Good stage format:

```text
阶段：
时间：
目标：
核心要解决：
关键动作：
本阶段输出：
```

For supply or operational scaling, express the manual-to-system path:

```text
前期：PGC 80% + 后台 20%
中期：PGC 40% + 后台 60%
后期：后台主导
```

This makes the document suitable for alignment because readers can see what is being validated now and what is intentionally deferred.

## 8. Style Notes

- Keep the opening compact; develop the key argument sections with enough paragraphs to make the judgment credible.
- Use `依据 -> 判断 -> 边界` more than generic `背景 -> 方案 -> 风险`.
- Use `这个结论支持 A，但不能支持 B` when evidence has limited scope.
- Use `不是这个阶段要解决的问题` when scope control is part of the judgment.
- Avoid turning audience intent into headings. "适合管理层对齐" should shape priority, evidence density, and boundary language, not appear as a literal title.
