---
name: yangjun-product-thinking
description: "Use for product-management documents that should reflect Yangjun's personal product judgment and communication style: boss or stakeholder alignment, business understanding, complex product reasoning, experiment analysis, project kickoff, scheme discussion, metric diagnosis, risk review, and rewriting product documents without flattening their reasoning into generic executive summaries."
---

# Yangjun Product Thinking

Use this skill to diagnose, draft, or rewrite product documents in a style closer to Yangjun's day-to-day product judgment.

## Required Workflow

Before writing or rewriting, read [thinking-profile.md](references/thinking-profile.md).

For management-alignment discussion docs, project opportunity analysis, staged project debates, or product strategy changes, also read [project-discussion-patterns.md](references/project-discussion-patterns.md).

Then perform a short diagnosis:

```text
文档类型：
读者应该获得什么：
原文最有价值的资产：
应该前置的内容：
应该后置或压缩的内容：
不能学/不能套用的内容：
建议改写策略：
```

Only then produce the output.

## Route By Task

- Boss or management-facing material -> use the "Boss-Facing Materials" section in `thinking-profile.md`. Do not assume every boss-facing document needs a decision memo.
- Cross-team alignment or discussion docs -> preserve the business question, reasoning spine, and explicit discussion points.
- Complex business judgment -> use the "Business Judgment Logic" section.
- Experiment review or metric diagnosis -> use the "Experiment And Data Reasoning" section.
- Project kickoff, one-pager, opportunity analysis, or scheme discussion -> use the "Project And Scheme Alignment" section and `project-discussion-patterns.md`. For team kickoff of a new product exploration, especially when moving from opportunity judgment to workstream execution, use "Team Kickoff For New Product Exploration" in `thinking-profile.md`.
- PRD detailed interaction requirements -> use the "PRD / Interaction Detail Writing" section in `thinking-profile.md`; keep strategic diagnosis out of the final requirement text unless it clarifies scope or dependency.
- Rewrite requests -> use the "Rewrite Procedure" and check "Anti-Patterns".

## Core Rules

- Choose the document mode before choosing the structure: thought sync, fast decision support, stage summary, business review, methodology, experiment recovery, or project kickoff.
- Preserve the source document's strongest reasoning asset. Do not compress a valuable logic chain into generic "结论 / 风险 / 下一步".
- Use concise but credible business language. Avoid management-consulting polish that weakens operational meaning.
- Make uncertainty explicit: distinguish direct measurement, proxy estimate, assumption, and decision boundary.
- For user-submitted text rewrites, default to compression unless the user explicitly asks to expand, explain, or add context. The rewritten text should be shorter than the source, or at most the same length. Do not add extra evaluative, transitional, or "positive summary" language that is not directly supported by facts.
- If the user's requested audience is mixed, such as "上下游及管理层", write for alignment and discussion first, then mark the decisions or inputs needed from each group.
- Treat audience and intent instructions as writing constraints, not literal section titles. If the user says "适合与上级对齐" or "面向协作方", reflect that through framing, priority, evidence density, risk language, and action clarity; do not create mechanical headings like "需要和上级对齐什么" unless the source itself calls for that explicit section.
- Do not default every requirement to tables. Use paragraphs for judgment, reasoning, transitions, and "why this matters"; use tables only when they genuinely improve comparison, data density,口径 alignment, option tradeoffs, or responsibility split. Good structure often means a short overview, richer paragraph development in the key argument sections, and selective tables as support.

## Quality Bar

The output should make readers clear on:

- What question is being discussed.
- Why it matters to the business or user path.
- What logic or evidence supports the current judgment.
- Which parts are known, assumed, uncertain, or only proxy-measured.
- What each audience group should discuss, confirm, decide, or execute next.
